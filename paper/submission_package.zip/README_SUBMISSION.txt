================================================================================
IEEE TRANSACTIONS SUBMISSION PACKAGE (TURNKEY FOR OVERLEAF / SCHOLARONE)
================================================================================
Paper Title:
How Much Recalibration Is Enough? Reliability of Cellular Throughput Forecasts
Across Networks with Missing Radio Telemetry

Author:
Md. Moazzem Hossain Majumder
Email: moazzemhossain1510@gmail.com

Target Venues:
1. IEEE Transactions on Network and Service Management (TNSM)
2. IEEE Open Journal of the Communications Society (OJ-COMS)
3. IEEE Access

Package Structure:
.
├── manuscript.tex            Master IEEEtran two-column LaTeX manuscript
├── references.bib            17 clean BibTeX references with official DOIs
├── cover_letter.tex          Editor-in-Chief submission cover letter (LaTeX)
├── cover_letter.md           Editor-in-Chief submission cover letter (Markdown)
├── tables/
│   ├── table1_point_predictors.tex
│   └── table2_main_benchmark.tex
└── figures/
    ├── fig1_budget_vs_usefulness.pdf / .png
    ├── fig2_subgroup_and_tradeoff.pdf / .png
    ├── fig3_aci_adaptation.pdf / .png
    ├── fig4_pareto_frontier.pdf / .png
    └── fig5_sla_cost_curve.pdf / .png

Instructions for Overleaf:
1. Log into https://www.overleaf.com
2. Select 'New Project' -> 'Upload Project'
3. Drag and drop this 'submission_package.zip' archive
4. Set compiler to pdfLaTeX and root document to 'manuscript.tex'
5. Click 'Recompile' -- it compiles immediately with 0 errors!
================================================================================
